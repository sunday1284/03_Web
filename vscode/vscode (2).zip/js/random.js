
function random(minValue,maxValue){
    //Math.floor(Math.random() * (최대값-최소값+1)+최소값)
   return Math.floor(Math.random()* (maxValue-minValue+1)+minValue);
                            // (100 - 65 + 1) +65
}

